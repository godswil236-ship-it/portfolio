GEEVIC portfolio - PythonAnywhere upload

1. PythonAnywhere > Web > Add a new web app > Flask (any Python 3).
2. Files tab > open /home/YOURUSERNAME/mysite/
3. Upload everything inside the "mysite" folder of this zip (flask_app.py and the static folder), replacing the old flask_app.py.
4. Web tab > click the green Reload button.
5. Open YOURUSERNAME.pythonanywhere.com

To update later: upload a new static/index.html and click Reload.
