from flask import Flask, send_from_directory, request, Response
import os, re, sqlite3, csv, io, secrets
from datetime import datetime, timedelta

# ====== CHANGE THIS PASSWORD before you upload ======
ADMIN_USER = "godswill"
ADMIN_PASS = "ChangeThisPassword123"
# ====================================================

app = Flask(__name__)
HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(HERE, "static")
DB = os.path.join(HERE, "visits.db")

def db():
    c = sqlite3.connect(DB)
    c.execute("CREATE TABLE IF NOT EXISTS visits(id INTEGER PRIMARY KEY, ts TEXT, ip TEXT, device TEXT, os TEXT, browser TEXT, source TEXT, ua TEXT)")
    return c

def parse_ua(ua):
    ua = ua or ""
    osn, dev = "Unknown", "Desktop/Other"
    m = re.search(r"Android [\d.]+; ([^;)]+)", ua)
    if m:
        osn, dev = "Android", m.group(1).replace(" Build", "").strip()
    elif "iPhone" in ua: osn, dev = "iOS", "iPhone"
    elif "iPad" in ua: osn, dev = "iOS", "iPad"
    elif "Windows" in ua: osn, dev = "Windows", "Computer"
    elif "Mac OS X" in ua: osn, dev = "macOS", "Mac"
    elif "Linux" in ua: osn, dev = "Linux", "Computer"
    br = "Other"
    for key, name in (("Edg/", "Edge"), ("OPR/", "Opera"), ("SamsungBrowser", "Samsung Internet"), ("Firefox", "Firefox"), ("FBAN", "Facebook app"), ("Instagram", "Instagram app"), ("Chrome", "Chrome"), ("Safari", "Safari")):
        if key in ua: br = name; break
    if "bot" in ua.lower() or "crawl" in ua.lower() or "spider" in ua.lower(): dev = "BOT"
    return dev, osn, br

def real_ip():
    xf = request.headers.get("X-Forwarded-For", "")
    return xf.split(",")[0].strip() if xf else request.remote_addr

def lagos(ts):
    return (datetime.strptime(ts, "%Y-%m-%d %H:%M:%S") + timedelta(hours=1)).strftime("%d %b %Y, %I:%M %p")

@app.route("/")
def home():
    try:
        ua = request.headers.get("User-Agent", "")
        dev, osn, br = parse_ua(ua)
        src = request.headers.get("Referer", "") or request.args.get("src", "") or "Direct / WhatsApp"
        c = db()
        c.execute("INSERT INTO visits(ts,ip,device,os,browser,source,ua) VALUES(?,?,?,?,?,?,?)",
                  (datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"), real_ip(), dev, osn, br, src[:200], ua[:300]))
        c.commit(); c.close()
    except Exception:
        pass
    r = send_from_directory(BASE, "index.html")
    r.headers["Cache-Control"] = "no-cache"
    return r

def authed():
    a = request.authorization
    return a and secrets.compare_digest(a.username or "", ADMIN_USER) and secrets.compare_digest(a.password or "", ADMIN_PASS)

def need_login():
    return Response("Login required", 401, {"WWW-Authenticate": 'Basic realm="GEEVIC admin"'})

@app.route("/admin")
def admin():
    if not authed(): return need_login()
    c = db()
    rows = c.execute("SELECT ts,ip,device,os,browser,source FROM visits ORDER BY id DESC LIMIT 300").fetchall()
    total = c.execute("SELECT COUNT(*) FROM visits WHERE device!='BOT'").fetchone()[0]
    uniq = c.execute("SELECT COUNT(DISTINCT ip) FROM visits WHERE device!='BOT'").fetchone()[0]
    today = (datetime.utcnow() + timedelta(hours=1)).strftime("%Y-%m-%d")
    td = c.execute("SELECT COUNT(*) FROM visits WHERE device!='BOT' AND date(ts,'+1 hour')=?", (today,)).fetchone()[0]
    c.close()
    esc = lambda s: (s or "").replace("&", "&amp;").replace("<", "&lt;")
    body = "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % esc(x) for x in (lagos(r[0]),) + r[1:]) for r in rows)
    html = """<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>Visitors</title>
<style>body{background:#0A0B0F;color:#E8EAF0;font:15px system-ui;margin:0;padding:18px}h1{color:#B6FF3B;margin:0 0 14px}
.s{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px}.s div{background:#14161D;border:1px solid #232734;border-radius:12px;padding:12px 18px}.s b{display:block;font-size:24px;color:#B6FF3B}
.w{overflow-x:auto}table{border-collapse:collapse;width:100%%;min-width:640px}td,th{border-bottom:1px solid #232734;padding:8px;text-align:left;font-size:13px}th{color:#9AA0AE}a{color:#B6FF3B}</style>
<h1>GEEVIC visitors</h1><div class=s><div><b>%d</b>total visits</div><div><b>%d</b>unique IPs</div><div><b>%d</b>today</div></div>
<p><a href="/admin/export.csv">Download CSV</a> &middot; Times are Nigeria time. Latest 300 shown. Bots are hidden from counts but listed as BOT.</p>
<div class=w><table><tr><th>Time</th><th>IP address</th><th>Phone / device</th><th>OS</th><th>Browser</th><th>Came from</th></tr>%s</table></div>""" % (total, uniq, td, body)
    return html

@app.route("/admin/export.csv")
def export():
    if not authed(): return need_login()
    c = db(); rows = c.execute("SELECT ts,ip,device,os,browser,source FROM visits ORDER BY id DESC").fetchall(); c.close()
    o = io.StringIO(); w = csv.writer(o); w.writerow(["time_utc", "ip", "device", "os", "browser", "source"]); w.writerows(rows)
    return Response(o.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=visitors.csv"})
